﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestApi.Models;

namespace RestApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private static List<Country> countries = new List<Country>()
        {
            new Country(){ Id = 0, Name = "Indonesia", Language = "Indonesia"},
            new Country(){ Id = 1, Name = "Jepang", Language = "Japan"}


        };
        [HttpGet]
        public IEnumerable<Country> Get() 
        { 
            return countries;
        
        }
        [HttpPost]
        
        public void Post([FromBody] Country country)
        {
            countries.Add(country);
        }

        [HttpPut("{Id}")]
        public void Put(int Id, [FromBody] Country country) 
        {
            countries[Id] = country;
        }

        [HttpDelete("{Id}")]
        public void Delete(int Id)
        {
            countries.Remove(countries[Id]);
         
        }
        
    }
}
