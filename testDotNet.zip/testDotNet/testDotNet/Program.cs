﻿using System;

namespace testDotNet
{
    class Program
    {
        static void Main(string[] args)
        {
            int size;
           

            Console.Write("masukkan banyak tampilan : ");
            size = Convert.ToInt32(Console.ReadLine());

            for(int i = 1; i <=size; i++)
            {
                for(int j = 1; j<=size -i; j++)
                {
                    Console.Write(" ");
                }
                for(int k = 1; k <= i; k++)
                {
                    Console.Write(" *");
                }
                Console.WriteLine();
            }
         
        }
    }
}



