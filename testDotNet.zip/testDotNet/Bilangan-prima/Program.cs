﻿using System;

namespace Bilangan_prima
{
    class Program
    {
        static void Main(string[] args)
        {

            // deklarasi variabel
            int bil;

           
            // main Menu
            Console.WriteLine("Program Check Bilangan Prima");
            Console.Write("Enter Number: ");
            bil = Convert.ToInt32(Console.ReadLine());
           
            int checker = 0;


            for (int i = 2; i <= bil; i++)
            {
                if (bil % i == 0)
                {
                    checker++;
                }
            }
            if (checker == 1)
            {
               Console.WriteLine(bil + " adalah bilangan prima");
               Console.WriteLine(bil+1);
            }
            else
            {
                Console.WriteLine(bil + " bukan bilangan prima");
            }
        }
    }
    }

